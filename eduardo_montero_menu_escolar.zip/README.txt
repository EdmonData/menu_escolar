users 

Admin Junaeb		admin@junaeb.cl		12345678
Eduardo			eduarmont@gmail.com	12345
Colegio Salesianos	salecianos@gmail.com	12345



npm start;



bd 
    user: 'eduardo',
    host: 'localhost',
    database: 'menu_escolar',
    password: 'calcetin',
    port: 5432,