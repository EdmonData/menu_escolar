const { Pool } = require('pg');
const pool = new Pool({
    user: 'eduardo',
    host: 'localhost',
    database: 'menu_escolar',
    password: 'calcetin',
    port: 5432,
});

const nuevoUsuario = async (nombre, email, password) => {
    const crearUsuario = {
    text: 'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING *;',
    values: [nombre, email, password],
}
try{
     const { rows } = await pool.query(crearUsuario);
    return rows[0];
} catch (e) {
    throw new Error(e);
}
}

const getUsuario = async (email, password) => {
    const usuario = {
        text: 'SELECT * FROM users WHERE email = $1 AND password = $2;',
        values: [email, password],
    }
    try{
        const { rows } = await pool.query(usuario);
        return rows[0];
    } catch (e) {
        throw new Error(e);
    }
};

const getAllOlderes   = async () => {
    const allOrders = 'SELECT * FROM orders;';
    try {
        const { rows } = await pool.query(allOrders);
        return rows;
    } catch (e) {
        throw new Error(e);
    }
};

const getOrdersByUser = async (id) => {
    const ordersByUser = {
        text: 'SELECT * FROM orders WHERE school_id = $1;',
        values: [id],
    }
    try {
        const { rows } = await pool.query(ordersByUser);
        return rows;
    } catch (e) {
        throw new Error(e);
    }
};


module.exports = {
    getUsuario,
    nuevoUsuario,
    getAllOlderes,
    getOrdersByUser,
};